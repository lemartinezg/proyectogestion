// TODO: agrega aquí una función HTTP para IA si la necesitas
