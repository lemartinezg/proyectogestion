# EmoFinance Starter

App React + Firebase para registrar gastos con emociones y evaluación por IA (baseline local).

## Requisitos
- Node 18+
- Cuenta de Firebase (habilita Authentication (Email/Password) y Firestore)

## Pasos
1) Clona/descomprime este proyecto.
2) Crea proyecto en Firebase y en *Project Settings → General* copia la config web.
3) En la raíz, crea **.env.local** basado en `.env.example` y pega tus keys.
4) En Firebase Console → *Authentication → Sign-in method* habilita **Email/Password**.
5) En *Firestore Database* crea la base en modo producción y publica `firestore.rules`.
6) Instala deps y arranca:
```bash
npm i
npm run dev
```
7) Abre `http://localhost:5173`.

## IA de ejemplo
- `src/lib/ai.js` contiene una heurística simple.
- Reemplázala por una Cloud Function propia o llamada a tu API.

## Dónde tocar
- UI principales: `ExpenseForm`, `Stats`, `ChatCoach`.
- Auth/Router: `src/pages/Login.jsx`, `src/auth/AuthProvider.jsx`.
- Firebase config: `src/firebase.js` y `.env.local`.
