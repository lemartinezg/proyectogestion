import { onSnapshot } from 'firebase/firestore'
import { useEffect, useState } from 'react'

export function useSnapshot(queryRef){
  const [rows, setRows] = useState([])
  const [error, setError] = useState(null)
  useEffect(()=>{
    if(!queryRef) return
    try{
      const unsub = onSnapshot(queryRef, snap=>{
        const data = snap.docs.map(d=>({ id:d.id, ...d.data() }))
        setRows(data)
      }, err=>{
        console.error('🔥 Error al escuchar Firestore:', err)
        setError(err)
      })
      return ()=>unsub()
    }catch(e){
      console.error('❌ useSnapshot falló:', e)
      setError(e)
    }
  },[queryRef])
  return { rows, error }
}
